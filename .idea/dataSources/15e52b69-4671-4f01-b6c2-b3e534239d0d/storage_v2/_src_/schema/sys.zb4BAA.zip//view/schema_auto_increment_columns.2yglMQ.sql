CREATE VIEW schema_auto_increment_columns AS
  SELECT
    `information_schema`.`columns`.`TABLE_SCHEMA`                                                             AS `table_schema`,
    `information_schema`.`columns`.`TABLE_NAME`                                                               AS `table_name`,
    `information_schema`.`columns`.`COLUMN_NAME`                                                              AS `column_name`,
    `information_schema`.`columns`.`DATA_TYPE`                                                                AS `data_type`,
    `information_schema`.`columns`.`COLUMN_TYPE`                                                              AS `column_type`,
    (locate('unsigned', `information_schema`.`columns`.`COLUMN_TYPE`) =
     0)                                                                                                       AS `is_signed`,
    (locate('unsigned', `information_schema`.`columns`.`COLUMN_TYPE`) >
     0)                                                                                                       AS `is_unsigned`,
    ((CASE `information_schema`.`columns`.`DATA_TYPE`
      WHEN 'tinyint'
        THEN 255
      WHEN 'smallint'
        THEN 65535
      WHEN 'mediumint'
        THEN 16777215
      WHEN 'int'
        THEN 4294967295
      WHEN 'bigint'
        THEN 18446744073709551615 END) >> if((locate('unsigned', `information_schema`.`columns`.`COLUMN_TYPE`) > 0), 0,
                                             1))                                                              AS `max_value`,
    `information_schema`.`tables`.`AUTO_INCREMENT`                                                            AS `auto_increment`,
    (`information_schema`.`tables`.`AUTO_INCREMENT` / ((CASE `information_schema`.`columns`.`DATA_TYPE`
                                                        WHEN 'tinyint'
                                                          THEN 255
                                                        WHEN 'smallint'
                                                          THEN 65535
                                                        WHEN 'mediumint'
                                                          THEN 16777215
                                                        WHEN 'int'
                                                          THEN 4294967295
                                                        WHEN 'bigint'
                                                          THEN 18446744073709551615 END) >> if((locate('unsigned',
                                                                                                       `information_schema`.`columns`.`COLUMN_TYPE`)
                                                                                                > 0), 0,
                                                                                               1)))           AS `auto_increment_ratio`
  FROM (`information_schema`.`columns`
    JOIN `information_schema`.`tables`
      ON (((`information_schema`.`columns`.`TABLE_SCHEMA` = `information_schema`.`tables`.`TABLE_SCHEMA`) AND
           (`information_schema`.`columns`.`TABLE_NAME` = `information_schema`.`tables`.`TABLE_NAME`))))
  WHERE (
    (`information_schema`.`columns`.`TABLE_SCHEMA` NOT IN ('mysql', 'sys', 'INFORMATION_SCHEMA', 'performance_schema'))
    AND (`information_schema`.`tables`.`TABLE_TYPE` = 'BASE TABLE') AND
    (`information_schema`.`columns`.`EXTRA` = 'auto_increment'))
  ORDER BY (`information_schema`.`tables`.`AUTO_INCREMENT` / ((CASE `information_schema`.`columns`.`DATA_TYPE`
                                                               WHEN 'tinyint'
                                                                 THEN 255
                                                               WHEN 'smallint'
                                                                 THEN 65535
                                                               WHEN 'mediumint'
                                                                 THEN 16777215
                                                               WHEN 'int'
                                                                 THEN 4294967295
                                                               WHEN 'bigint'
                                                                 THEN 18446744073709551615 END) >> if((locate(
                                                                                                           'unsigned',
                                                                                                           `information_schema`.`columns`.`COLUMN_TYPE`)
                                                                                                       > 0), 0,
                                                                                                      1))) DESC,
    ((CASE `information_schema`.`columns`.`DATA_TYPE`
      WHEN 'tinyint'
        THEN 255
      WHEN 'smallint'
        THEN 65535
      WHEN 'mediumint'
        THEN 16777215
      WHEN 'int'
        THEN 4294967295
      WHEN 'bigint'
        THEN 18446744073709551615 END) >>
     if((locate('unsigned', `information_schema`.`columns`.`COLUMN_TYPE`) > 0), 0, 1));

